import type { Node } from '@xyflow/react';

/**
 * Calculates the position for a new child node (below the parent).
 */
export function getChildNodePosition(parentNode: Node): { x: number; y: number } {
  return {
    x: parentNode.position.x,
    y: parentNode.position.y + 100,
  };
}

/**
 * Calculates the position for a new sibling node (beside the parent).
 */
export function getSiblingNodePosition(parentNode: Node): { x: number; y: number } {
  return {
    x: parentNode.position.x + 200,
    y: parentNode.position.y,
  };
}
