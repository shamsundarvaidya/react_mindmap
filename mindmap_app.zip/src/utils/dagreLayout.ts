import dagre from 'dagre';
import type { Node, Edge } from '@xyflow/react';

const nodeWidth = 150;
const nodeHeight = 60;

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

interface LayoutOptions {
  direction?: 'TB' | 'BT' | 'LR' | 'RL'; // Top-Bottom, Bottom-Top, Left-Right, Right-Left
}

export function getDagreLayoutedElements(
  nodes: Node[],
  edges: Edge[],
  options: LayoutOptions = { direction: 'TB' }
): { nodes: Node[]; edges: Edge[] } {
  const { direction } = options;

  dagreGraph.setGraph({ rankdir: direction });

  // Set dagre nodes with size
  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  // Set dagre edges
  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  // Compute layout
  dagre.layout(dagreGraph);

  // Update node positions based on Dagre result
  const layoutedNodes = nodes.map((node) => {
    const pos = dagreGraph.node(node.id);
    return {
      ...node,
      position: {
        x: pos.x - nodeWidth / 2,
        y: pos.y - nodeHeight / 2,
      },
      // optional: prevent dragging after layout
      draggable: false,
    };
  });

  return { nodes: layoutedNodes, edges };
}
