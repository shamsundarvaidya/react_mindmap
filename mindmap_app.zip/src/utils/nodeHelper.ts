import type { Node, Edge } from '@xyflow/react';
import { nanoid } from '@reduxjs/toolkit';
import { getChildNodePosition, getSiblingNodePosition } from './layoutHelper';
import {type NodeData } from '../types/mindmap';

export type NodeWithEdge = {
    node: Node<NodeData>;
    edge: Edge;
};

export const createChildNodeWithEdge = (parentNode: Node<NodeData>): NodeWithEdge => {
    const newId = nanoid();
    const parentId = parentNode.id;
    const newPosition = getChildNodePosition(parentNode);

    const childNode = {
        id: newId,
        type: 'customNode',
        position: newPosition,
        data: { label: `Node ${newId}` },
    };

    const childEdge = {
          id: `e${parentId}-${newId}`,
          source: parentId,
          target: newId,
        };



    return { node: childNode, edge: childEdge };
};

export const createSiblingNodeWithEdge = (parentNode: Node<NodeData>, parentEdge: Edge): NodeWithEdge => {
    const newId = nanoid();
    const newPosition = getSiblingNodePosition(parentNode);

    const siblingNode = {
        id: newId,
        type: 'customNode',
        position: newPosition,
        data: { label: `Node ${newId}` },
    };

    const siblingEdge = {
            id: `e${parentEdge.source}-${newId}`,
            source: parentEdge.source,
            target: newId,
          };

    return { node: siblingNode, edge: siblingEdge };
};



