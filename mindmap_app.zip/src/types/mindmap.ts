import type { Node, Edge } from '@xyflow/react';

export interface NodeData extends Record<string, unknown> {
  label: string;
}

export interface MindMapState {
  nodes: Node<NodeData>[];
  edges: Edge[];
  selectedNodeId: string | null;
}

export type AddNodeType = 'child' | 'sibling';
