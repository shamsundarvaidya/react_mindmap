import { Provider } from 'react-redux';
import { store } from './store';
import MindMap from './components/MindMap';

export default function App() {
  
 
  return (
    <Provider store={store}>
      <MindMap />
    </Provider>
  );
}
