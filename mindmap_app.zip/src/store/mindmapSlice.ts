import { createSlice, type PayloadAction, nanoid } from "@reduxjs/toolkit";
import type { MindMapState, AddNodeType, NodeData } from "../types/mindmap";
import {
  createChildNodeWithEdge,
  createSiblingNodeWithEdge,
  type NodeWithEdge,
} from "../utils/nodeHelper";
import {
  type Node,
  type Edge,
  applyNodeChanges,
  applyEdgeChanges,
  type NodeChange,
  type EdgeChange,
} from "@xyflow/react";

const initialState: MindMapState = {
  nodes: [
    {
      id: "root",
      type: "customNode",
      position: { x: 250, y: 100 },
      data: { label: "Root Node" },
    },
  ],
  edges: [],
  selectedNodeId: "root",
};

const mindmapSlice = createSlice({
  name: "mindmap",
  initialState,
  reducers: {
    selectNode(state, action: PayloadAction<string>) {
      console.log("Selected node ID:", action.payload);
      state.selectedNodeId = action.payload;
    },
    applyNodeChangesAction(
      state,
      action: PayloadAction<NodeChange<Node<NodeData>>[]>
    ) {
      console.log("Applying node changes");
      state.nodes = applyNodeChanges<Node<NodeData>>(
        action.payload,
        state.nodes
      );
    },

    applyEdgeChangesAction(state, action: PayloadAction<EdgeChange[]>) {
      console.log("Applying edge changes");
      state.edges = applyEdgeChanges(action.payload, state.edges);
    },

    deleteNodeAndDescendants: (state, action: PayloadAction<string>) => {
      const idToDelete = action.payload;

      const findAllDescendants = (
        nodeId: string,
        edges: Edge[]
      ): Set<string> => {
        const descendants = new Set<string>();
        const queue = [nodeId];

        while (queue.length > 0) {
          const current = queue.shift()!;
          descendants.add(current);

          const children = edges
            .filter((e) => e.source === current)
            .map((e) => e.target);

          queue.push(...children);
        }

        return descendants;
      };

      const descendants = findAllDescendants(idToDelete, state.edges);

      // Filter out nodes and edges with matching IDs
      state.nodes = state.nodes.filter((node) => !descendants.has(node.id));
      state.edges = state.edges.filter(
        (edge) => !descendants.has(edge.source) && !descendants.has(edge.target)
      );

      // Deselect if deleted
      if (descendants.has(state.selectedNodeId!)) {
        state.selectedNodeId = null;
      }
    },

    addNode(state, action: PayloadAction<{ type: AddNodeType }>) {
      console.log("Adding node of type:", action.payload.type);
      const { type } = action.payload;
      const parentId = state.selectedNodeId;
      if (!parentId) return;

      const parentNode = state.nodes.find((n) => n.id === parentId);
      if (!parentNode) return;

      if (type === "child") {
        const { node, edge }: NodeWithEdge =
          createChildNodeWithEdge(parentNode);
        state.nodes.push(node);
        state.edges.push(edge);
      } else if (type === "sibling") {
        const parentEdge = state.edges.find((e) => e.target === parentId);
        if (parentEdge) {
          const { node, edge }: NodeWithEdge = createSiblingNodeWithEdge(
            parentNode,
            parentEdge
          );
          state.nodes.push(node);
          state.edges.push(edge);
        }
      }
    },
    updateNodeLabel(
      state,
      action: PayloadAction<{ id: string; label: string }>
    ) {
      const { id, label } = action.payload;
      const node = state.nodes.find((n) => n.id === id);
      if (node) {
        node.data.label = label;
      }
    },
  },
});

export const {
  selectNode,
  addNode,
  applyNodeChangesAction,
  applyEdgeChangesAction,
  updateNodeLabel,
  deleteNodeAndDescendants,
} = mindmapSlice.actions;

export default mindmapSlice.reducer;
