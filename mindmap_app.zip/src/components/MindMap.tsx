import React, { useCallback } from 'react';
import { useAppSelector, useAppDispatch } from '../store';
import { addNode, selectNode, applyEdgeChangesAction, applyNodeChangesAction } from '../store/mindmapSlice';
import CustomNode from './CustomNode';
import ControlPanel from './ControlPanel';
import { ReactFlow, Background, Controls, MiniMap, type NodeChange,  type EdgeChange, type Node, useConnection } from '@xyflow/react';

import '@xyflow/react/dist/style.css';
import type { NodeData } from '../types/mindmap';

const nodeTypes = {
  customNode: CustomNode,
};

const MindMap = () => {
    const { nodes, edges, selectedNodeId } = useAppSelector(state => state.mindmap);
    const dispatch = useAppDispatch();

    const onNodesChange = useCallback((changes: NodeChange<Node<NodeData>>[]) => {
    dispatch(applyNodeChangesAction(changes));
  },[dispatch])

  const onEdgesChange = useCallback((changes: EdgeChange[]) => {
    dispatch(applyEdgeChangesAction(changes));
  }, [dispatch])

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    dispatch(selectNode(node.id));
  }, [dispatch])

    return (
    <div className="h-screen flex flex-col">
      <ControlPanel />
      <div className="flex-1">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodeClick={onNodeClick}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          fitView
        >
          <Background />
          <Controls />
          <MiniMap />
        </ReactFlow>
      </div>
    </div>
  );


};
export default MindMap;