import React from 'react';
import { useAppDispatch, useAppSelector } from '../store';
import { addNode,deleteNodeAndDescendants } from '../store/mindmapSlice';

const ControlPanel = () => {
  const dispatch = useAppDispatch();
  const { selectedNodeId, edges } = useAppSelector((state) => state.mindmap);


  const isRootNode = (id: string) => {
    return !edges.some((e) => e.target === id);
  };

    const handleDelete = () => {
    if (!selectedNodeId) return;

    if (isRootNode(selectedNodeId)) {
      alert("Cannot delete the root node.");
      return;
    }

    const confirmed = window.confirm("Are you sure you want to delete this node and all its children?");
    if (confirmed) {
      dispatch(deleteNodeAndDescendants(selectedNodeId));
    }
  };


  return (
    <div className="p-4 bg-gray-100 border-b flex gap-4">
      <button
        className="bg-blue-600 text-white px-4 py-2 rounded"
        onClick={() => dispatch(addNode({ type: 'child' }))}
        disabled={!selectedNodeId}
      >
        Add Child Node
      </button>
      <button
        className="bg-green-600 text-white px-4 py-2 rounded"
        onClick={() => dispatch(addNode({ type: 'sibling' }))}
        disabled={!selectedNodeId}
      >
        Add Sibling Node
      </button>

      <button
        className="bg-red-600 text-white px-4 py-2 rounded"
        onClick={handleDelete}
        disabled={!selectedNodeId}
      >
        Delete Node
      </button>
    </div>
  );
};

export default ControlPanel;
