import React, { useState, useEffect, useRef } from 'react';
import { Handle, Position, type NodeProps, type Node } from '@xyflow/react';
import { useAppDispatch } from '../store';
import { updateNodeLabel } from '../store/mindmapSlice';
import type { NodeData } from '../types/mindmap';

const CustomNode: React.FC<NodeProps<Node<NodeData>>> = ({ id, data }) => {
  const dispatch = useAppDispatch();
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(data.label);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus on input when editing starts
  useEffect(() => {
    if (editing) {
      inputRef.current?.focus();
    }
  }, [editing]);

  const handleDoubleClick = () => {
    setEditing(true);
  };

  const handleBlur = () => {
    dispatch(updateNodeLabel({ id, label: value }));
    setEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      inputRef.current?.blur();
    }
  };


  return (
    <div className="bg-white border rounded shadow-md px-4 py-2 text-center min-w-[150px]" onDoubleClick={handleDoubleClick}>
      <Handle type="target" position={Position.Left} />
      {editing ? (
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          className="w-full border rounded px-2 py-1 text-sm"
        />
      ) : (
        <div className="font-semibold text-sm">{data.label}</div>
      )}
      <Handle type="source" position={Position.Right} />
    </div>
  );
};

export default CustomNode;
