import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import {
  type Node,
  type Edge,
  type NodeChange,
  type EdgeChange,
  applyNodeChanges,
  applyEdgeChanges,
  type Connection,
  addEdge,
} from '@xyflow/react';

interface FlowState {
  nodes: Node[];
  edges: Edge[];
}

const initialState: FlowState = {
  nodes: [{id: 'n1', position : {x: 0, y: 0}, data : {label: 'Node1'},},
          {id: 'n2', position : {x: 0, y: 200}, data : {label: 'Node2'},}
  ],
  edges: [],
};

const flowSlice = createSlice({
  name: 'flow',
  initialState,
  reducers: {
    // Set full arrays
    setNodes: (state, action: PayloadAction<Node[]>) => {
      state.nodes = action.payload;
    },
    setEdges: (state, action: PayloadAction<Edge[]>) => {
      state.edges = action.payload;
    },
    addNode: (state, action: PayloadAction<Node>) => {
      state.nodes.push(action.payload);
    },

    // Changes from React Flow
    nodeChanges: (state, action: PayloadAction<NodeChange[]>) => {
      state.nodes = applyNodeChanges(action.payload, state.nodes);
    },
    edgeChanges: (state, action: PayloadAction<EdgeChange[]>) => {
      state.edges = applyEdgeChanges(action.payload, state.edges);
    },

    // Connection (add edge)
    addConnection: (state, action: PayloadAction<Connection>) => {
      state.edges = addEdge(action.payload, state.edges);
    },
  },
});

export const { addNode,setNodes, setEdges, nodeChanges, edgeChanges, addConnection } = flowSlice.actions;
export default flowSlice.reducer;
