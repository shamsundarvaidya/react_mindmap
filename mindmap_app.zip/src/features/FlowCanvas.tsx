import React from 'react';


import '@xyflow/react/dist/style.css';
import {
  Background,
  Controls,
  type OnConnect,
  type Node
} from '@xyflow/react';

import { ReactFlow } from '@xyflow/react';

import { useSelector, useDispatch } from 'react-redux';
import { type RootState } from '../app/store';
import { type AppDispatch } from '../app/store';
import {
  nodeChanges,
  edgeChanges,
  addConnection,
  setNodes,
  addNode
} from './flowSlice';



const FlowCanvas = () => {
  const dispatch = useDispatch<AppDispatch>();
  const nodes = useSelector((state: RootState) => state.flow.nodes);
  const edges = useSelector((state: RootState) => state.flow.edges);
  const testNode: Node = {id: 'test', position : {x: 150, y: 0}, data : {label: 'test'}}
  console.log(nodes)
  const handleClick = () => {
    alert('Button clicked!');
    dispatch(addNode(testNode))
  };

  return (
    <div style={{ width: '1000px', height: '800px' }}>
      <div className="container mx-auto p-4">
      <button
      className={`bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline`}
      onClick={handleClick}
    >
      Add Node
    </button>
    </div>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={(changes) => dispatch(nodeChanges(changes))}
        onEdgesChange={(changes) => dispatch(edgeChanges(changes))}
        onConnect={(connection) => dispatch(addConnection(connection))}
        fitView
      >
        <Controls />
        <Background />
      </ReactFlow>
    </div>
  );
};

export default FlowCanvas;



